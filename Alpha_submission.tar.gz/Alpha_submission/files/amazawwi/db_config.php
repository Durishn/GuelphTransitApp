<?php

/**
 * Datbase connection Information
 *
 * @author     Anthony Mazzawi <amazzawi@mail.uoguelph.ca>
 */

define('DB_USER', "root");
define('DB_PASSWORD', "VelocityRaptors");
define('DB_DATABASE', "GuelphTransit");
define('DB_SERVER', "localhost");

?>
